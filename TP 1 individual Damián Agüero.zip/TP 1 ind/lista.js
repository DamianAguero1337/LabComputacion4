
function aplicarEstiloFondo() {
  var tabla = document.getElementById("tablaUsuarios").getElementsByTagName("tbody")[0];
  var filas = tabla.getElementsByTagName("tr");
  
  for (var i = 0; i < filas.length; i++) {
      var usuario = filas[i].getElementsByTagName("td")[2].innerText; // Estado de bloqueo en la tercera celda
      
      if (usuario === "N") {
          filas[i].style.backgroundColor = "#cef8c6"; //verde
      } else {
          filas[i].style.backgroundColor = "#fd9f8b"; //rojo
      }
  }
}


function cargarUsuarios() {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "http://168.194.207.98:8081/tp/lista.php?action=BUSCAR", true);

  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      var usuarios = JSON.parse(xhr.responseText);
      var tabla = document.getElementById("tablaUsuarios").getElementsByTagName("tbody")[0];

      tabla.innerHTML = ""; // Limpiar tabla antes de cargar los datos

      if (usuarios.length > 0) {
        usuarios.forEach(function(usuario) {
          var row = tabla.insertRow();
          row.insertCell(0).innerText = usuario.id;
          row.insertCell(1).innerText = usuario.usuario;
          row.insertCell(2).innerText = usuario.bloqueado;
          row.insertCell(3).innerText = usuario.apellido;
          row.insertCell(4).innerText = usuario.nombre;

          
          var bloquearBtn = document.createElement("button");
          bloquearBtn.onclick = function() {
            bloquearUsuario(usuario.id, "Y");
          };

          
          var bloquearImg = document.createElement("img");
          bloquearImg.src = "bloquear.png";
          bloquearImg.width = 20;
          bloquearImg.height = 20;
          bloquearBtn.appendChild(bloquearImg);

          var bloquearCell = row.insertCell(5);
          bloquearCell.appendChild(bloquearBtn);

          
          var desbloquearBtn = document.createElement("button");
          desbloquearBtn.onclick = function() {
            bloquearUsuario(usuario.id, "N");
          };

          
          var desbloquearImg = document.createElement("img");
          desbloquearImg.src = "desbloquear.png";
          desbloquearImg.width = 20;
          desbloquearImg.height = 20;
          desbloquearBtn.appendChild(desbloquearImg);

          var desbloquearCell = row.insertCell(6);
          desbloquearCell.appendChild(desbloquearBtn);

          
          
        });
      } else {
        tabla.innerHTML = "<tr><td colspan='7'>No se encontraron usuarios.</td></tr>";
      }
    }
  };

  xhr.send();
}

  
var busquedaActual = ""; // Variable para almacenar el término de búsqueda actual

function buscar() {
    busquedaActual = document.getElementById("busqueda").value;
    var url = "http://168.194.207.98:8081/tp/lista.php?action=BUSCAR&usuario=" + encodeURIComponent(busquedaActual);
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
  
    xhr.onreadystatechange = function() {
      if (xhr.readyState == 4 && xhr.status == 200) {
        var usuarios = JSON.parse(xhr.responseText);
        var tabla = document.getElementById("tablaUsuarios").getElementsByTagName("tbody")[0];
  
        tabla.innerHTML = ""; 
  
        if (usuarios.length > 0) {
          usuarios.forEach(function(usuario) {
            var row = tabla.insertRow();
            row.insertCell(0).innerText = usuario.id;
            row.insertCell(1).innerText = usuario.usuario;
            row.insertCell(2).innerText = usuario.bloqueado;
            row.insertCell(3).innerText = usuario.apellido;
            row.insertCell(4).innerText = usuario.nombre;

            // Botón de bloquear
            var bloquearBtn = document.createElement("button");
            bloquearBtn.onclick = function() {
              bloquearUsuario(usuario.id, "Y");
            };
            var bloquearImg = document.createElement("img");
            bloquearImg.src = "bloquear.png";
            bloquearImg.width = 20;
            bloquearImg.height = 20;
            bloquearBtn.appendChild(bloquearImg);

            // Botón de desbloquear
            var desbloquearBtn = document.createElement("button");
            desbloquearBtn.onclick = function() {
              bloquearUsuario(usuario.id, "N");
            };
            var desbloquearImg = document.createElement("img");
            desbloquearImg.src = "desbloquear.png";
            desbloquearImg.width = 20;
            desbloquearImg.height = 20;
            desbloquearBtn.appendChild(desbloquearImg);

            // Añadir botones a la fila
            var bloquearCell = row.insertCell(5);
            bloquearCell.appendChild(bloquearBtn);
            var desbloquearCell = row.insertCell(6);
            desbloquearCell.appendChild(desbloquearBtn);
          });
        } else {
          tabla.innerHTML = "<tr><td colspan='7'>No se encontraron usuarios.</td></tr>";
        }
        
        // Aplicar estilo de fondo
        aplicarEstiloFondo();
      }
    };
  
    xhr.send();
}

function bloquearUsuario(idUsuario, estado) {
    var xhr = new XMLHttpRequest();
    var url = "http://168.194.207.98:8081/tp/lista.php?action=BLOQUEAR&idUser=" + idUsuario + "&estado=" + estado;
    xhr.open("GET", url, true);
    
    xhr.onreadystatechange = function() {
      if (xhr.readyState == 4 && xhr.status == 200) {
        buscar(); // Volver a aplicar la búsqueda después de bloquear o desbloquear
      }
    };
  
    xhr.send();
}



window.onload = function() {
    buscar(); // Realizar búsqueda al cargar la página inicialmente
};