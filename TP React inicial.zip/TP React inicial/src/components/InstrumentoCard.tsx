import React from 'react';
import { Card, Col, Row } from 'react-bootstrap';
import { Instrumento } from '../types/types';

interface InstrumentoCardProps {
    instrumento: Instrumento;
}

const InstrumentoCard: React.FC<InstrumentoCardProps> = ({ instrumento }) => {
    let envioElement;

    if (instrumento.costoEnvio === 'G') {
        envioElement = (
            <div className="envio-gratis">
                <img src="instrumentos/camion.png" alt="Camión de envío gratis" />
                <span style={{ color: 'green' }}>Envío gratis a todo el país</span>
            </div>
        );
    } else {
        const costoEnvioColor = 'orange';
        envioElement = (
            <p className="costo-envio" style={{ color: costoEnvioColor }}>
                Costo de envío: ${instrumento.costoEnvio}
            </p>
        );
    }

    return (
        <Card className="mb-3" >
            <Card.Body>
                <Row>
                    <Col xs={4}>
                        <img src={`/instrumentos/${instrumento.imagen}`} alt={instrumento.instrumento} style={{ maxWidth: '100%' }} />
                    </Col>
                    <Col xs={8}>
                        <h5>{instrumento.instrumento}</h5>
                        <p>Precio: ${instrumento.precio}</p>
                        {envioElement}
                        <p>Cantidad vendida: {instrumento.cantidadVendida}</p>
                        <p>{instrumento.descripcion}</p>
                    </Col>
                </Row>
            </Card.Body>
        </Card>
    );
}

export default InstrumentoCard;
