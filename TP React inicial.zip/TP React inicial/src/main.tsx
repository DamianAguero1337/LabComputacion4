import React from 'react';
import ReactDOM from 'react-dom/client';
import ListInstrumentos from './pages/ListInstrumentos';

const root = document.getElementById('root');

if (root) {
  const rootElement = ReactDOM.createRoot(root);
  rootElement.render(
    <React.StrictMode>
      <ListInstrumentos />
    </React.StrictMode>
  );
} else {
  console.error('Element with id "root" not found in the document.');
}
