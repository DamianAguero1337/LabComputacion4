import React, { useState, useEffect } from 'react';
import InstrumentoCard from '../components/InstrumentoCard';
import {Instrumento} from '../types/types.ts'

const ListInstrumentos: React.FC = () => {
    const [instrumentos, setInstrumentos] = useState<Instrumento[]>([]);

    useEffect(() => {
        
        fetch('src/data/instrumentos.json') 
            .then(response => response.json())
            .then(data => setInstrumentos(data.instrumentos)); 
    }, []);

    return (
            <div className="Listainstrumentos">
                {instrumentos.map((instrumento: Instrumento) => (
                    <InstrumentoCard key={instrumento.id} instrumento={instrumento} />
                ))}
            </div>
    );
}

export default ListInstrumentos;
