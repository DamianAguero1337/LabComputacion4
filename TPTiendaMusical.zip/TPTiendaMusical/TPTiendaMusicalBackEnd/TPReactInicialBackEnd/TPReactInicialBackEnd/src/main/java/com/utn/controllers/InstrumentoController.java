package com.utn.TPReactInicialBackEnd.controllers;

import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.utn.TPReactInicialBackEnd.entities.Istrumento;
import com.utn.TPReactInicialBackEnd.services.InstrumentoServiceImpl;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path= "instrumentos")

public EmpresaController(InstrumentoServiceImpl servicio) {
        super(servicio);
        }
        }
