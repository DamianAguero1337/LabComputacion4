package com.utn.TPReactInicialBackEnd.repositories;

import org.springframework.stereotype.Repository;
import org.utn.tp1lab4.entities.Instrumento;

@Repository
public interface InstrumentoRepository extends IBaseRepository<Instrumento, Long> {
}
