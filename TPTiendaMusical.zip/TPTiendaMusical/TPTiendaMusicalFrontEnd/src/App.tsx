
import { AppRouter } from "./routes/AppRouter.tsx";

function App() {
  

  return (
    <>
    <AppRouter/>
    </>
  )
}

export default App