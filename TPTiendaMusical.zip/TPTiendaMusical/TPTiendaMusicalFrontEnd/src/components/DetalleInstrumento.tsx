import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Instrumento } from "../types/types";
import styles from "../styles/DetalleInstrumento.module.css";

export const DetalleInstrumento = () => {
  const { id } = useParams<{ id: string }>(); // Obtener el ID del instrumento de la URL
  const [instrumento, setInstrumento] = useState<Instrumento | null>(null);

  useEffect(() => {
    const fetchInstrumento = async () => {
      try {
        const response = await fetch(`/api/instrumentos/${id}`); // Cambiar la ruta si es necesario
        const data = await response.json();
        setInstrumento(data);
      } catch (error) {
        console.error("Error al obtener el instrumento:", error);
      }
    };

    fetchInstrumento();
  }, [id]);

  return (
    <div>
      {instrumento && (
        <div className={styles.container}>
          <div className={styles.imagenContainer}>
            <img src={`/img/${instrumento.imagen}`} alt={instrumento.instrumento} />
          </div>
          <div className={styles.descripcionContainer}>
            <h3>{instrumento.instrumento}</h3>
            <p>{instrumento.descripcion}</p>
          </div>
          <div className={styles.infoContainer}>
            <p><strong>Cantidad Vendida:</strong> {instrumento.cantidadVendida}</p>
            <p><strong>Nombre:</strong> {instrumento.instrumento}</p>
            <p><strong>Precio:</strong> ${instrumento.precio}</p>
            <p><strong>Marca:</strong> {instrumento.marca}</p>
            <p><strong>Modelo:</strong> {instrumento.modelo}</p>
            <p><strong>Costo de Envío:</strong> {instrumento.costoEnvio === 'G' ? 'Envío gratis a todo el país' : `$${instrumento.costoEnvio}`}</p>
            <button>Agregar al carrito</button>
          </div>
        </div>
      )}
    </div>
  );
};

