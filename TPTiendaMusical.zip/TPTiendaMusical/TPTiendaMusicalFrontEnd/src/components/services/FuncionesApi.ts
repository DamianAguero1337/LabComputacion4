import express, { Request, Response } from 'express';
import sqlite3 from 'sqlite3';

const app = express();
const port = 3000;

// Conexión a la base de datos SQLite
const db = new sqlite3.Database('InstrumentosDB.db', sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error('Error al abrir la base de datos:', err.message);
  } else {
    console.log('Conexión exitosa a la base de datos');
  }
});

// Ruta para obtener todos los instrumentos
app.get('/instrumentos', (req: Request, res: Response) => {
  db.all('SELECT * FROM instrumentos', (err, rows) => {
    if (err) {
      console.error('Error al obtener los instrumentos:', err.message);
      res.status(500).json({ error: 'Error al obtener los instrumentos' });
    } else {
      res.json(rows);
    }
  });
});

// Ruta para obtener un instrumento por su ID
app.get('/instrumentos/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  db.get('SELECT * FROM instrumentos WHERE id = ?', [id], (err, row) => {
    if (err) {
      console.error('Error al obtener el instrumento:', err.message);
      res.status(500).json({ error: 'Error al obtener el instrumento' });
    } else if (!row) {
      res.status(404).json({ error: 'Instrumento no encontrado' });
    } else {
      res.json(row);
    }
  });
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
