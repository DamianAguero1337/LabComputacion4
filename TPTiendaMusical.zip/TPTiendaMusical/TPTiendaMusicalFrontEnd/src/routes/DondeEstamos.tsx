

export const DondeEstamos = () => {
  return (
    <div>
      <h2>Estamos ubicados en:</h2>
      <iframe
        src="https://www.google.com.ar/maps/place/Av.+San+Mart%C3%ADn+%26+Av.+Las+Heras,+Capital,+Mendoza/@-32.8863197,-68.8382777,17z/data=!4m6!3m5!1s0x967e091ed2dd83f7:0xf41c7ab7e3522157!8m2!3d-32.8863197!4d-68.8382777!16s%2Fg%2F11hb9x4grs?entry=ttu"
        width="600"
        height="450"
        loading="lazy"
        title="Ubicación"
        style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
        }}
      ></iframe>
    </div>
  );
};

