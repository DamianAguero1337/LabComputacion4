package com.utn.TPReactInicialBackEnd.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import com.utn.TPReactInicialBackEnd.entities.Base;

import java.io.Serializable;

@NoRepositoryBean
public interface IBaseRepository<E extends Base, Id extends Serializable> extends JpaRepository<E, Id> {
}