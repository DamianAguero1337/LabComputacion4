import React, { useState, useEffect } from "react";
import Grilla from "../components/Grilla";
import InstrumentoModal from "../components/InstrumentoModal";
import BtnFiltrarCategoria from "../components/BtnFiltrarCategoria";
import styles from "../styles/ABM.module.css";
import { Instrumento } from "../types/types";

const ABM: React.FC = () => {
  const [instrumentos, setInstrumentos] = useState<Instrumento[]>([]);
  const [selectedCategoria, setSelectedCategoria] = useState<string | null>(null);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [selectedInstrumento, setSelectedInstrumento] = useState<Instrumento | null>(null);



  // Función para manejar la selección de categoría
  const handleCategoriaChange = (denominacion: string ) => {
    setSelectedCategoria(denominacion);
  };

  // Función para abrir el modal de edición o creación de instrumento
  const handleShowModal = (instrumento: Instrumento | null) => {
    setSelectedInstrumento(instrumento);
    setShowModal(true);
  };

  // Función para cerrar el modal
  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedInstrumento(null);
  };

  return (
    <div>
      <h1>Administracion de instrumentos</h1>
      <BtnFiltrarCategoria onSelectCategoria={handleCategoriaChange} />
      <Grilla
        instrumentos={instrumentos}
        selectedCategoria={selectedCategoria}
        onEdit={handleShowModal}
      />
      <InstrumentoModal
        show={showModal}
        instrumento={selectedInstrumento}
        onClose={handleCloseModal}
      />
    </div>
  );
};

export default ABM;
