
import Carousel from 'react-bootstrap/Carousel';
import homeImage1 from "/img/homeImage1.jpeg";
import homeImage2 from "/img/homeImage2.jpeg";
import homeImage3 from "/img/homeImage3.jpeg";
import styles from "../styles/Home.module.css";

export const Home = () => {
  return (
    <div className={styles.home}>
      <h2>Musical Hendrix</h2>
      <Carousel>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={homeImage1}
            alt="Instrumento 1"
          />
          <Carousel.Caption>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={homeImage2}
            alt="Instrumento 2"
          />
          <Carousel.Caption>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={homeImage3}
            alt="Instrumento 3"
          />
          <Carousel.Caption>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
      <p>Musical Hendrix es una tienda de instrumentos musicales con ya más de 15 años de 
        experiencia. Tenemos el conocimiento y la capacidad como para informarte acerca de las 
        mejores elecciones para tu compra musical. </p>
    </div>
  );
};
