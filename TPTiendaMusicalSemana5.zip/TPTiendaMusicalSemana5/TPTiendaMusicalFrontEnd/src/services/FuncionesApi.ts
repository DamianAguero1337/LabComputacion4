import express, { Request, Response } from 'express';
import sqlite3 from 'sqlite3';
import { IGenericFetch } from './IGenericFetch';

const app = express();
const port = 3000;

class SQLiteFetch<T> implements IGenericFetch<T> {
  private db: sqlite3.Database;

  constructor(dbPath: string) {
    this.db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE, (err) => {
      if (err) {
        console.error('Error al abrir la base de datos:', err.message);
      } else {
        console.log('Conexión exitosa a la base de datos');
      }
    });
  }

  getAll(): Promise<T[]> {
    return new Promise((resolve, reject) => {
      this.db.all('SELECT * FROM instrumentos', (err, rows) => {
        if (err) {
          console.error('Error al obtener los instrumentos:', err.message);
          reject('Error al obtener los instrumentos');
        } else {
          resolve(rows as T[]);
        }
      });
    });
  }

  getById(id: number): Promise<T | null> {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT * FROM instrumentos WHERE id = ?', [id], (err, row) => {
        if (err) {
          console.error('Error al obtener el instrumento:', err.message);
          reject('Error al obtener el instrumento');
        } else if (!row) {
          resolve(null);
        } else {
          resolve(row as T);
        }
      });
    });
  }

   create(data: T): Promise<T> {
    return new Promise((resolve, reject) => {
      const keys = Object.keys(data).join(', ');
      const placeholders = Object.keys(data).map(() => '?').join(', ');
      const values = Object.values(data);

      const sql = `INSERT INTO ${this.tableName} (${keys}) VALUES (${placeholders})`;
      
      this.db.run(sql, values, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  }

   update(id: number, data: T): Promise<T> {
    return new Promise((resolve, reject) => {
      const updates = Object.keys(data).map(key => `${key} = ?`).join(', ');
      const values = Object.values(data);
      values.push(id);

      const sql = `UPDATE ${this.tableName} SET ${updates} WHERE id = ?`;
      
      this.db.run(sql, values, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  }

   delete(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      const sql = `DELETE FROM ${this.tableName} WHERE id = ?`;
      
      this.db.run(sql, id, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

// Ruta para obtener todos los instrumentos
app.get('/instrumentos', async (req: Request, res: Response) => {
  const fetcher = new SQLiteFetch('InstrumentosDB.db');
  try {
    const instrumentos = await fetcher.getAll();
    res.json(instrumentos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Ruta para obtener un instrumento por su ID
app.get('/instrumentos/:id', async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const fetcher = new SQLiteFetch('InstrumentosDB.db');
  try {
    const instrumento = await fetcher.getById(id);
    if (instrumento) {
      res.json(instrumento);
    } else {
      res.status(404).json({ error: 'Instrumento no encontrado' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});