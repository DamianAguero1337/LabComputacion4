package com.utn.TPReactInicialBackEnd.repositories;

import org.springframework.stereotype.Repository;
import com.utn.TPReactInicialBackEnd.entities.Categoria;


@Repository
public interface CategoriaRepository extends IBaseRepository<Categoria, Long> {

}
