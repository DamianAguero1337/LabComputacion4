package com.utn.TPReactInicialBackEnd.repositories;

import org.springframework.stereotype.Repository;
import com.utn.TPReactInicialBackEnd.entities.Instrumento;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;

@Repository
public interface InstrumentoRepository extends IBaseRepository<Instrumento, Long> {
    Page<Instrumento> findByCategoria(Pageable pageable, long id);
}

