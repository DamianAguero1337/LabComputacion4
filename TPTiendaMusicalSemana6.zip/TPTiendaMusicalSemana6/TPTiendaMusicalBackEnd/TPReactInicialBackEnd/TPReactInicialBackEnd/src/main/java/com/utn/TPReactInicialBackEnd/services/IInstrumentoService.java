package com.utn.TPReactInicialBackEnd.services;

import com.utn.TPReactInicialBackEnd.entities.Instrumento;

public interface IInstrumentoService extends IBaseService<Instrumento, Long> {

}
