package com.utn.TPReactInicialBackEnd.services;

import com.utn.TPReactInicialBackEnd.entities.Pedido;

public interface IPedidoService extends IBaseService<Pedido, Long> {

}
