package com.utn.TPReactInicialBackEnd.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.utn.TPReactInicialBackEnd.entities.Pedido;
import com.utn.TPReactInicialBackEnd.repositories.IBaseRepository;
import com.utn.TPReactInicialBackEnd.repositories.PedidoRepository;

@Service
public class PedidoServiceImpl extends BaseServiceImpl<Pedido, Long> implements IPedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    public PedidoServiceImpl(IBaseRepository<Pedido, Long> baseRepository, PedidoRepository pedidoRepository) {
        super(baseRepository);
        this.pedidoRepository = pedidoRepository;
    }
}