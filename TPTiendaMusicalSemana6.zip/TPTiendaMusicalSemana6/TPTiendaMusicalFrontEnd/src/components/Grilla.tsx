

import React from 'react';
import { Instrumento } from '../types/types';
import InstrumentoItem from './InstrumentoItem';

interface GrillaInstrumentos {
  instrumentos: Instrumento[];
  filtroCategoria?: string;
}

const Grilla: React.FC<GrillaInstrumentos> = ({ instrumentos, filtroCategoria }) => {
  const instrumentosFiltrados = filtroCategoria
    ? instrumentos.filter((instrumento) => instrumento.idCategoria)
    : instrumentos;

  return (
    <div>
      <h2>Instrumentos</h2>
      <div className="instrumento-grid">
        {instrumentosFiltrados.map((instrumento) => (
          <InstrumentoItem key={instrumento.id} instrumento={instrumento} />
        ))}
      </div>
    </div>
  );
};

export default Grilla;