import React from 'react';
import { Instrumento } from '../types/types';

interface InstrumentoItemProps {
  instrumento: Instrumento;
}

const InstrumentoItem: React.FC<InstrumentoItemProps> = ({ instrumento }) => {
  return (
    <div className="instrumento-item">
      <h3>{instrumento.instrumento}</h3>
      <p>Marca: ${instrumento.marca}</p>
      <p>Modelo: ${instrumento.modelo}</p>
      <p>Imagen: ${instrumento.imagen}</p>
      <p>Precio: ${instrumento.precio}</p>
      <p>Costo de envio: ${instrumento.costoEnvio}</p>
      <p>Cantida Vendida: ${instrumento.cantidadVendida}</p>
      <p>Descripcion: ${instrumento.descripcion}</p>
      <p>Categoria: ${instrumento.idCategoria}</p>
      
    </div>
  );
};

export default InstrumentoItem;