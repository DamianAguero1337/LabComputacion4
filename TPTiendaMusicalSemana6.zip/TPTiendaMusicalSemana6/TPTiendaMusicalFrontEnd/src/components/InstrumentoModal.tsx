import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { CategoriaInstrumento } from '../types/types';
import { Instrumento } from '../types/types';

interface InstrumentoModalProps {
  categorias: CategoriaInstrumento[];
  onSubmit: (instrumento: string, marca: string, modelo: string, imagen: string, precio: number, 
    costoEnvio: string, descripcion: string, idCategoria: number) => void;
}

const InstrumentoModal: React.FC<InstrumentoModalProps> = ({ categorias, onSubmit }) => {
  const [show, setShow] = useState(false);
  const [instrumento, setInstrumento] = useState('');
  const [marca, setMarca] = useState('');
  const [modelo, setModelo] = useState('');
  const [imagen, setImagen] = useState('');
  const [precio, setPrecio] = useState(0);
  const [costoEnvio, setCostoEnvio] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [idCategoria, setIdCategoria] = useState(0);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    onSubmit(instrumento, marca, modelo, imagen, precio, costoEnvio, descripcion, idCategoria);
    handleClose();
  };

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Agregar/Editar Instrumento
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Agregar Nuevo Instrumento</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formInstrumento">
              <Form.Label>instrumento</Form.Label>
              <Form.Control type="text" value={instrumento} onChange={(e) => setInstrumento(e.target.value)} />
            </Form.Group>
           
            <Form.Group controlId="formMarca">
              <Form.Label>marca</Form.Label>
              <Form.Control type="text" value={marca} onChange={(e) => setMarca(e.target.value)} />
            </Form.Group>

            
            <Form.Group controlId="formModelo">
              <Form.Label>modelo</Form.Label>
              <Form.Control type="text" value={modelo} onChange={(e) => setModelo(e.target.value)} />
            </Form.Group>

           
            <Form.Group controlId="formImagen">
              <Form.Label>imagen</Form.Label>
              <Form.Control type="text" value={imagen} onChange={(e) => setImagen(e.target.value)} />
            </Form.Group>
            <Form.Group controlId="formPrecio">
              <Form.Label>precio</Form.Label>
              <Form.Control type="number" value={precio} onChange={(e) => setPrecio(parseFloat(e.target.value))} />
            </Form.Group>
            <Form.Group controlId="formCostoEnvio">
              <Form.Label>Costo de envio</Form.Label>
              <Form.Control as="textarea" rows={3} value={costoEnvio} onChange={(e) => setCostoEnvio(e.target.value)} />
            </Form.Group>
            <Form.Group controlId="formDescripcion">
              <Form.Label>Descripcion</Form.Label>
              <Form.Control type="text" value={descripcion} onChange={(e) => setDescripcion(e.target.value)} />
            </Form.Group>
            <Form.Group controlId="formIdCategoria">
              <Form.Label>Categoría</Form.Label>
              <Form.Control as="select" value={idCategoria} onChange={(e) => setIdCategoria(e.target.value)}>
                <option value="">Seleccionar categoría...</option>
                {categorias.map((categoria) => (
                  <option key={categoria.id} value={categoria.id}>
                    {categoria.id}
                  </option>
                ))}
              </Form.Control>
            </Form.Group>
            <Button variant="primary" type="submit">
              Agregar
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default InstrumentoModal;
