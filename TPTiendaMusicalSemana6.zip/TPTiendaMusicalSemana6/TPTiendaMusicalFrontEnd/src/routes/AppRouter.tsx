import {Route, Routes} from "react-router-dom"
import { Home } from "./Home"
import { DondeEstamos } from "./DondeEstamos"
import { Productos } from "./Productos"
import Menu  from "../components/Menu"
import ABM from "./ABM"


export const AppRouter = () => {
  return (
    <div>   
    <Menu/>
    <Routes>
        <Route path= "/" element={<Home />}/>
        <Route path= "/dondeEstamos " element={<DondeEstamos />}/>
        <Route path= "/productos " element={<Productos />}/>
        <Route path= "/abm " element={<ABM />}/>
    </Routes>
    </div>
  )
}
