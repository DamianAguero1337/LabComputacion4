import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Instrumento } from "../types/types";


export const Productos = () => {
  const [instrumentos, setInstrumentos] = useState<Instrumento[]>([]);

  useEffect(() => {
    const fetchInstrumentos = async () => {
      try {
        const response = await fetch("/instrumentos"); 
        const data = await response.json();
        setInstrumentos(data);
      } catch (error) {
        console.error("Error al obtener los instrumentos:", error);
      }
    };

    fetchInstrumentos();
  }, []);

  return (
    <div>
      <h2>Listado de Productos</h2>
      <ul>
        {instrumentos.map((instrumento: Instrumento) => (
          <li key={instrumento.id}>
            <Link to={`/instrumentos/${instrumento.id}`}>{instrumento.instrumento}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

