import { Instrumento, CategoriaInstrumento } from '../types/types';

const API_URL = 'http://localhost:3000';

export const fetchInstrumentos = async (): Promise<Instrumento[]> => {
  const response = await fetch(`${API_URL}/instrumentos`);
  if (!response.ok) {
    throw new Error('Error al obtener los instrumentos');
  }
  return response.json();
};

export const fetchCategorias = async (): Promise<CategoriaInstrumento[]> => {
  const response = await fetch(`${API_URL}/categorias`);
  if (!response.ok) {
    throw new Error('Error al obtener las categorías');
  }
  return response.json();
};

export const saveInstrumento = async (instrumento: Instrumento): Promise<void> => {
  const method = instrumento.id ? 'PUT' : 'POST';
  const url = instrumento.id ? `${API_URL}/instrumentos/${instrumento.id}` : `${API_URL}/instrumentos`;

  const response = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(instrumento),
  });

  if (!response.ok) {
    throw new Error('Error al guardar el instrumento');
  }
};

export const deleteInstrumento = async (id: number): Promise<void> => {
  const response = await fetch(`${API_URL}/instrumentos/${id}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    throw new Error('Error al eliminar el instrumento');
  }
};
