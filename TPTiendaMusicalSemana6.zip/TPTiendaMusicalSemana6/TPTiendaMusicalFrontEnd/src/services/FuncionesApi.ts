import express, { Request, Response } from 'express';
import sqlite3 from 'sqlite3';
import bodyParser from 'body-parser';

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Conexión a la base de datos SQLite
const db = new sqlite3.Database('InstrumentosDB.db', (err) => {
  if (err) {
    console.error('Error al abrir la base de datos:', err.message);
  } else {
    console.log('Conexión exitosa a la base de datos');
  }
});

// Ruta para obtener todos los instrumentos
app.get('/instrumentos', (req: Request, res: Response) => {
  db.all('SELECT * FROM instrumentos', (err, rows) => {
    if (err) {
      console.error('Error al obtener los instrumentos:', err.message);
      res.status(500).json({ error: 'Error al obtener los instrumentos' });
    } else {
      res.json(rows);
    }
  });
});

// Ruta para obtener un instrumento por su ID
app.get('/instrumentos/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  db.get('SELECT * FROM instrumentos WHERE id = ?', [id], (err, row) => {
    if (err) {
      console.error('Error al obtener el instrumento:', err.message);
      res.status(500).json({ error: 'Error al obtener el instrumento' });
    } else if (!row) {
      res.status(404).json({ error: 'Instrumento no encontrado' });
    } else {
      res.json(row);
    }
  });
});

// Ruta para crear un nuevo instrumento
app.post('/instrumentos', (req: Request, res: Response) => {
  const { instrumento, marca, modelo, imagen, precio, costoEnvio, cantidadVendida, descripcion, idCategoria } = req.body;
  const query = `INSERT INTO instrumentos (instrumento, marca, modelo, imagen, precio, costoEnvio, cantidadVendida, descripcion, idCategoria) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  db.run(query, [instrumento, marca, modelo, imagen, precio, costoEnvio, cantidadVendida, descripcion, idCategoria], function (err) {
    if (err) {
      console.error('Error al crear el instrumento:', err.message);
      res.status(500).json({ error: 'Error al crear el instrumento' });
    } else {
      res.status(201).json({ id: this.lastID });
    }
  });
});

// Ruta para actualizar un instrumento por su ID
app.put('/instrumentos/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const { instrumento, marca, modelo, imagen, precio, costoEnvio, cantidadVendida, descripcion, idCategoria } = req.body;
  const query = `UPDATE instrumentos SET instrumento = ?, marca = ?, modelo = ?, imagen = ?, precio = ?, costoEnvio = ?, cantidadVendida = ?, descripcion = ?, idCategoria = ? WHERE id = ?`;
  db.run(query, [instrumento, marca, modelo, imagen, precio, costoEnvio, cantidadVendida, descripcion, idCategoria, id], function (err) {
    if (err) {
      console.error('Error al actualizar el instrumento:', err.message);
      res.status(500).json({ error: 'Error al actualizar el instrumento' });
    } else if (this.changes === 0) {
      res.status(404).json({ error: 'Instrumento no encontrado' });
    } else {
      res.status(200).json({ message: 'Instrumento actualizado' });
    }
  });
});

// Ruta para eliminar un instrumento por su ID
app.delete('/instrumentos/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const query = `DELETE FROM instrumentos WHERE id = ?`;
  db.run(query, [id], function (err) {
    if (err) {
      console.error('Error al eliminar el instrumento:', err.message);
      res.status(500).json({ error: 'Error al eliminar el instrumento' });
    } else if (this.changes === 0) {
      res.status(404).json({ error: 'Instrumento no encontrado' });
    } else {
      res.status(200).json({ message: 'Instrumento eliminado' });
    }
  });
});

// Ruta para obtener todas las categorías
app.get('/categorias', (req: Request, res: Response) => {
  db.all('SELECT * FROM categorias', (err, rows) => {
    if (err) {
      console.error('Error al obtener las categorías:', err.message);
      res.status(500).json({ error: 'Error al obtener las categorías' });
    } else {
      res.json(rows);
    }
  });
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
