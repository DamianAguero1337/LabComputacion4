package com.utn.TPReactInicialBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpReactInicialBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpReactInicialBackEndApplication.class, args);
	}

}
