package com.utn.TPReactInicialBackEnd.controllers;

import com.utn.TPReactInicialBackEnd.entities.Pedido;
import com.mercadopago.MercadoPagoConfig;
import com.mercadopago.client.preference.PreferenceBackUrlsRequest;
import com.mercadopago.client.preference.PreferenceClient;
import com.mercadopago.client.preference.PreferenceItemRequest;
import com.mercadopago.client.preference.PreferenceRequest;
import com.mercadopago.resources.preference.Preference;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class MercadoPagoController {

    public PreferenceMP getPreferenciaIdMercadoPago(Pedido pedido){
        try {
            MercadoPagoConfig.setAccessToken("TEST-3338616763581427-050919-253499feffaf088a4a558702e27ddb17-96867950");
            PreferenceItemRequest itemRequest = PreferenceItemRequest.builder()
                    .id(pedido.getPedidoId())
                    .title("HENDRIX MUSICAL")
                    .description("Pedido realizado en MUSICAL HENDRIX")
                    .pictureUrl("https://th.bing.com/th/id/R.38aaac95c04eefe05975f350a26e8884?rik=c7efq1ofXQhKtg&riu=http%3a%2f%2f4.bp.blogspot.com%2f-9MPZp2U1BB4%2fU2qLj4LdB-I%2fAAAAAAAABLo%2fjux3LlW3swQ%2fs1600%2fVENTA-INSTRUMENTOS-GUITARRAS-LAS-PALMAS.JPG&ehk=Jek2QqYt93xy8N0w64DtV%2fNun4xI8RMpU4nK6DbACsQ%3d&risl=&pid=ImgRaw&r=0")
                    .quantity(1)
                    .currencyId("ARG")
                    .unitPrice(new BigDecimal(pedido.getMontoTotal()))
                    .build();
            List<PreferenceItemRequest> items = new ArrayList<>();
            items.add(itemRequest);

            PreferenceBackUrlsRequest backURL = PreferenceBackUrlsRequest.builder().success("http://localhost:5173/mpsuccess")
                    .pending("http://localhost:5173/mppending").failure("http://localhost:5173/mpfailure").build();

            PreferenceRequest preferenceRequest = PreferenceRequest.builder()
                    .items(items)
                    .backUrls(backURL)
                    .build();
            PreferenceClient client = new PreferenceClient();
            Preference preference = client.create(preferenceRequest);

            PreferenceMP mpPreference = new PreferenceMP();
            mpPreference.setStatusCode(preference.getResponse().getStatusCode());
            mpPreference.setId(preference.getId());
            return mpPreference;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
