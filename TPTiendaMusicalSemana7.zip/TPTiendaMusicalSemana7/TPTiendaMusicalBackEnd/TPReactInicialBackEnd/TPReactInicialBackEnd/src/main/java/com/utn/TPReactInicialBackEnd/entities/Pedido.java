package com.utn.TPReactInicialBackEnd.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pedido extends Base{
    private Date fechaPedido;
    private Double totalPedido;

    @OneToMany
    @JoinColumn(name = "idPedidoDetalle")
    @Builder.Default
    private Set<PedidoDetalle> detallesPedidos = new HashSet<>();
}