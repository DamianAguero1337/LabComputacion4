package com.utn.TPReactInicialBackEnd.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.utn.TPReactInicialBackEnd.entities.Instrumento;
import com.utn.TPReactInicialBackEnd.repositories.IBaseRepository;
import com.utn.TPReactInicialBackEnd.repositories.InstrumentoRepository;

@Service
public class InstrumentoServiceImpl extends BaseServiceImpl<Instrumento, Long> implements IInstrumentoService {

    @Autowired
    private InstrumentoRepository instrumentoRepository;

    public InstrumentoServiceImpl(IBaseRepository<Instrumento, Long> baseRepository, InstrumentoRepository instrumentoRepository) {
        super(baseRepository);
        this.instrumentoRepository = instrumentoRepository;
    }

    @Override
    @Transactional
    public Page<Instrumento> findAllByCategoria(Pageable pageable, long id) throws Exception{
        try {
            Page<Instrumento> instrumentos = instrumentoRepository.findByCategoria(pageable, id);
            if (instrumentos.isEmpty()) {
                throw new Exception("No se encontraron instrumentos para la categoria con el ID: " + id);
            }
            List<Instrumento> instrumentosByCategoriaX = new ArrayList<>();
            for (Instrumento instrumento : instrumentos) {
                if (instrumento != null ) {
                    instrumentosByCategoriaX.add(new Instrumento(instrumento));
                } else {
                    instrumentosByCategoriaX.add(instrumento);
                }
            }
            System.out.println("instrumentos" + instrumentosByCategoriaX);
            return new PageImpl<>(instrumentosByCategoriaX, pageable, instrumentos.getTotalElements());
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

}

