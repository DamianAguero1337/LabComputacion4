import React from 'react';
import { CategoriaInstrumento } from '../types/types';

interface CategoriaSelectProps {
  categorias: CategoriaInstrumento[];
  onChange: (categoria: string) => void;
}

const BtnFiltrarCategorias: React.FC<CategoriaSelectProps> = ({ categorias, onChange }) => {
  return (
    <div>
      <label htmlFor="categoria">Filtrar por Categoría:</label>
      <select id="categoria" onChange={(e) => onChange(e.target.value)}>
        <option value="">Todas</option>
        {categorias.map((categoria) => (
          <option key={categoria.id} value={categoria.id}>
            {categoria.denominacion}
          </option>
        ))}
      </select>
    </div>
  );
};

export default BtnFiltrarCategorias;