export default class PreferenceMP {

  id: string = '';
  statusCode:number = 0;

}
