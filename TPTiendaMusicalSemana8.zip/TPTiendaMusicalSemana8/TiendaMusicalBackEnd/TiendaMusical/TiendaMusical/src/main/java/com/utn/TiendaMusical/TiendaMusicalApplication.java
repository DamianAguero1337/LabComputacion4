package com.utn.TiendaMusical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaMusicalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaMusicalApplication.class, args);
	}

}
