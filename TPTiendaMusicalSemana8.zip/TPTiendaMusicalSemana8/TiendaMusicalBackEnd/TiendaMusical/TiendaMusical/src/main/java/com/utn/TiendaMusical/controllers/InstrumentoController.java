package com.utn.TiendaMusical.controllers;

import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.utn.TiendaMusical.entities.Instrumento;
import com.utn.TiendaMusical.services.InstrumentoServiceImpl;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path= "instrumentos")

public class InstrumentoController extends BaseControllerImpl<Instrumento, InstrumentoServiceImpl>{

    public InstrumentoController(InstrumentoServiceImpl servicio) {
        super(servicio);
    }

    @GetMapping("/categoria/{id}")
    public ResponseEntity<?> getAllByCategoria(Pageable pageable, @PathVariable Long id){
        try{
            return ResponseEntity
                    .status(HttpStatus.OK)
                    .body(servicio.findAllByCategoria(pageable, id));
        }catch (Exception e){
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("{\"error\":\""+ e.getMessage() + "\"}");
        }
    }
}