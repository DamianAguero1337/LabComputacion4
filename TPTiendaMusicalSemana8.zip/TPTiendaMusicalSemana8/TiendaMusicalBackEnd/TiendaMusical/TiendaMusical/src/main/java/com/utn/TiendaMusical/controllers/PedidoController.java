package com.utn.TiendaMusical.controllers;

import com.utn.TiendaMusical.entities.Pedido;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.utn.TiendaMusical.services.PedidoServiceImpl;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path= "pedido")

public class PedidoController extends BaseControllerImpl<Pedido, PedidoServiceImpl>{

    public PedidoController(PedidoServiceImpl servicio) {
        super(servicio);
    }
}
