package com.utn.TiendaMusical.controllers;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.utn.TiendaMusical.entities.Usuario;
import com.utn.TiendaMusical.services.UsuarioServiceImpl;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path= "usuario")

public class UsuarioController extends BaseControllerImpl<Usuario, UsuarioServiceImpl>{

    public UsuarioController(UsuarioServiceImpl servicio) {
        super(servicio);
    }
}