package com.utn.TiendaMusical.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Instrumento extends Base{

    @Column(length = 128)
    private String instrumento;
    @Column(length = 128)
    private String marca;
    @Column(length = 128)
    private String modelo;
    @Column(length = 128)
    private String imagen;
    private double precio;
    @Column(length = 128)
    private String costoEnvio;
    private int cantidadVendida;
    @Column(length = 2048)
    private String descripcion;
    private Long idCategoria;
}
