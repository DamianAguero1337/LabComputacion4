package com.utn.TiendaMusical.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pedido extends Base{
    private Date fechaPedido;
    private Double totalPedido;

    @OneToMany
    @JoinColumn(name = "idPedidoDetalle")
    @Builder.Default
    private Set<PedidoDetalle> detallesPedidos = new HashSet<>();
}