package com.utn.TiendaMusical.entities;

import jakarta.persistence.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;

public class Usuario extends Base{
    private Long id;
    @Column(length = 128)
    private String nombreUsuario;
    @Column(length = 128)
    private String clave;
    @Column(length = 128)
    private String rol;

    public Usuario(long id, String nombreUsuario, String clave, String rol) throws NoSuchAlgorithmException {
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        setClave(clave);
        setRol(rol);
    }
        public long getId() {
            return id;
        }

        public String getNombreUsuario() {
            return nombreUsuario;
        }

        public String getClave() {
            return clave;
        }

        public String getRol() {
            return rol;
        }

        public void setId(long id) {
            this.id = id;
        }

        public void setNombreUsuario(String nombreUsuario) {
            this.nombreUsuario = nombreUsuario;
        }

        public void setClave(String clave) throws NoSuchAlgorithmException {
            this.clave = encriptarClave(clave);
        }

        public void setRol(String rol) { this.rol = rol;}

        private String encriptarClave(String clave) throws NoSuchAlgorithmException {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] digest = md.digest(clave.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        }

        @Override
        public String toString() {
            return "Usuario{" +
                    "id=" + id +
                    ", nombreUsuario='" + nombreUsuario + '\'' +
                    ", clave='" + clave + '\'' +
                    ", rol='" + rol + '\'' +
                    '}';
        }
    }
}