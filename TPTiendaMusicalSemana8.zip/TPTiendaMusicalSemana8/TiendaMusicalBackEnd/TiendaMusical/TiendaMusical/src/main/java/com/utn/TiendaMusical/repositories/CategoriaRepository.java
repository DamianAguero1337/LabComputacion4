package com.utn.TiendaMusical.repositories;

import org.springframework.stereotype.Repository;
import com.utn.TiendaMusical.entities.Categoria;


@Repository
public interface CategoriaRepository extends IBaseRepository<Categoria, Long> {

}
