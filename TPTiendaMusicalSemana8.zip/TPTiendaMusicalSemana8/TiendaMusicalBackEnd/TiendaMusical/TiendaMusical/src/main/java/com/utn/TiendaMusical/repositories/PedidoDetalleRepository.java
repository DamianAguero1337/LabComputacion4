package com.utn.TiendaMusical.repositories;

import org.springframework.stereotype.Repository;
import com.utn.TiendaMusical.entities.PedidoDetalle;


@Repository
public interface PedidoDetalleRepository extends IBaseRepository<PedidoDetalle, Long> {

}