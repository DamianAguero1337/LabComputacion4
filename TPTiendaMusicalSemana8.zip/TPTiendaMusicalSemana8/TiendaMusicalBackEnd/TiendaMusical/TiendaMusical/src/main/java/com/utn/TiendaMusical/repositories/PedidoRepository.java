package com.utn.TiendaMusical.repositories;

import org.springframework.stereotype.Repository;
import com.utn.TiendaMusical.entities.Pedido;


@Repository
public interface PedidoRepository extends IBaseRepository<Pedido, Long> {

}