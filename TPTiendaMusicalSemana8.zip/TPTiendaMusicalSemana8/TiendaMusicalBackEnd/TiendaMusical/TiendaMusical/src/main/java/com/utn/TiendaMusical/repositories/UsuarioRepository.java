package com.utn.TiendaMusical.repositories;

import org.springframework.stereotype.Repository;
import com.utn.TiendaMusical.entities.Usuario;

@Repository
public interface UsuarioRepository extends IBaseRepository<Usuario, Long> {

}
