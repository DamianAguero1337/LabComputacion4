package com.utn.TiendaMusical.services;

import com.utn.TiendaMusical.entities.Instrumento;

public interface IInstrumentoService extends IBaseService<Instrumento, Long> {

}
