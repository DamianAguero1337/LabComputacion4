package com.utn.TiendaMusical.services;

import com.utn.TiendaMusical.entities.Pedido;

public interface IPedidoService extends IBaseService<Pedido, Long> {

}
