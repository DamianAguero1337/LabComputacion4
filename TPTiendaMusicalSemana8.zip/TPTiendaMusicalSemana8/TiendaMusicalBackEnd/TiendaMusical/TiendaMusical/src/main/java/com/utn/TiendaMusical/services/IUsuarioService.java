package com.utn.TiendaMusical.services;

import com.utn.TiendaMusical.entities.Usuario;

public interface IUsuarioService extends IBaseService<Usuario, Long> {

}