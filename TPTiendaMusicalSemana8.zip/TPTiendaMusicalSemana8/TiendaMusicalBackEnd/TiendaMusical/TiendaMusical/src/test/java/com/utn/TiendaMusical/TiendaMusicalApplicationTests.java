package com.utn.TiendaMusical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaMusicalApplicationTests {

	@Test
	void contextLoads() {
	}

}
