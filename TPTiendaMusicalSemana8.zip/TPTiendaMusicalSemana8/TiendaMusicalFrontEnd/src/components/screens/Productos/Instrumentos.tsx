import { useState, useEffect } from "react";
import styles from "/src/styles/Instrumentos.module.css";
import { Link } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import Cart from "../../ui/Cart/Cart";
import { Categoria, Instrumento } from "../../../types/instrumento";

const Instrumentos = () => {
  const [instrumentos, setInstrumentos] = useState<Instrumento[]>([]);
  const [instrumentosBaja, setInstrumentosBaja] = useState<Instrumento[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);

  const [selectedCategory, setSelectedCategory] = useState<Categoria | null>();

  const fetchCategorias = async () => {
    try {
      const response = await fetch(
        "http://localhost:8080/instrumentos/categorias"
      );
      const data = await response.json();
      setCategorias(data);
    } catch (error) {
      console.error("Error fetching categories:", error);
      console.log("error: ", error);
    }
  };
  const fetchInstrumentos = async () => {
    try {
      const response = await fetch(
        "http://localhost:8080/instrumentos/productos"
      );
      const data = await response.json();
      const instrumentosSinBaja = data.filter(
        (instrumento: Instrumento) => !instrumento.baja
      );
      const instrumentosConBaja = data.filter(
        (instrumento: Instrumento) => instrumento.baja
      );
      setInstrumentos(instrumentosSinBaja);
      setInstrumentosBaja(instrumentosConBaja);
    } catch (error) {
      console.error("Error al obtener los instrumentos:", error);
    }
  };

  useEffect(() => {
    fetchCategorias();
    fetchInstrumentos();
  }, [selectedCategory]); // 

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const categoryId = parseInt(e.target.value);
    const selected = categorias.find(
      (categoria) => categoria.id === categoryId
    );
    setSelectedCategory(selected || null);
  };
  const arrayInstrumentosFiltrados = instrumentos.filter(
    (instrumento) => instrumento.idCategoria?.id === selectedCategory?.id
  );

  const results = !selectedCategory ? instrumentos : arrayInstrumentosFiltrados;


  return (
    <div>
      <div
        className={styles.contenedorPrincipal}
        style={{ display: "flex", justifyContent: "space-between" }}
      >
        <div className={styles.filtrarPorCategoria}>
          <h2>Filtrar por Categoría</h2>
          <select value={selectedCategory?.id} onChange={handleCategoryChange}>
            <option value="">Todas las categorías</option>
            {categorias.map((categoria: Categoria) => (
              <option key={categoria.id} value={categoria.id}>
                {categoria.denominacion}
              </option>
            ))}
          </select>
        </div>
        <Cart />
      </div>
      {results.map((instrumento: Instrumento) => (
        <div key={instrumento.id}>
          <div className={styles.containerInstrumento}>
            <img src={`/img/${instrumento.imagen}`} />
            <div className={styles.containerTextoInstrumento}>
              <h3 className={styles.robotoTitulo}>{instrumento.instrumento}</h3>
              <h2
                className={styles.robotoCuerpo}
                style={{ fontSize: "1.6rem", fontWeight: "400" }}
              >
                $ {instrumento.precio}
              </h2>
              <span className={styles.robotoCuerpoNegrita}>
                {instrumento.costoEnvio === "G" ||
                instrumento.costoEnvio === "g" ? (
                  <div
                    className={`${styles.costoEnvioTexto} ${styles.costoEnvioTextoGratis}`}
                  >
                    <span
                      className="material-symbols-outlined"
                      style={{ marginRight: "5px" }}
                    >
                      local_shipping
                    </span>
                    <p style={{ margin: "0" }}>
                      Envío gratis para todo el país{" "}
                    </p>
                  </div>
                ) : (
                  <div
                    className={`${styles.costoEnvioTexto} ${styles.costoEnvioTextoPago}`}
                  >
                    Costo de Envío interior de Argentina $
                    {instrumento.costoEnvio}
                  </div>
                )}
              </span>
              <p className={styles.robotoCuerpo}>
                {instrumento.cantidadVendida} vendidos
              </p>
            </div>
            <Link to={`/productos/${instrumento.id}`}>
              <button
                className={styles.button}
                style={{
                  marginLeft: "2rem",
                  width: "13vw",
                  height: "5vw",
                }}
              >
                Ver detalles
              </button>
            </Link>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Instrumentos;