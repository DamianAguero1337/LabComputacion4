import { Carousel as CarouselComponent } from "react-bootstrap";
import "./CarouselHome.css";

function Carousel() {
  return (
    <CarouselComponent fade>
      <CarouselComponent.Item className="imgSlider">
        <img
          className="d-block w-100"
          src="https://e1.pxfuel.com/desktop-wallpaper/235/768/desktop-wallpaper-gibson-sg.jpg"
        />
      </CarouselComponent.Item>
      <CarouselComponent.Item className="imgSlider">
        <img
          className="d-block w-100 "
          src="https://horadelrecreo.com/wp-content/uploads/2019/04/instrumentos-de-percusion31.jpg"
        />
      </CarouselComponent.Item>
      <CarouselComponent.Item className="imgSlider">
        <img
          className="d-block w-100"
          src="https://th.bing.com/th/id/R.cb74bab3bb9237bf898cc2aea7759fa9?rik=pyCx%2b1u50Hx5uw&riu=http%3a%2f%2f5b0988e595225.cdn.sohucs.com%2fimages%2f20180725%2f874641f3287347a1887c24f8c992db9d.jpeg&ehk=1t3PQE0wIuzsg%2fhdfUG89saFAYE0MyafN%2buP4uOrdKI%3d&risl=&pid=ImgRaw&r=0"
        />
      </CarouselComponent.Item>
    </CarouselComponent>
  );
}

export default Carousel;
