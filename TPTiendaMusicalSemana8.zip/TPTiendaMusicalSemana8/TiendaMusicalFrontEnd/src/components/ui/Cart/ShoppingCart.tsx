import React, { useState } from "react";
import Cart from "./Cart";

type Product = {
  id: number;
  name: string;
  price: number;
  shipping: string; 
};

type CartItem = {
  product: Product;
  quantity: number;
};

export const ShoppingCart: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);


  const addToCart = (product: Product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find(
        (item) => item.product.id === product.id
      );
      if (existingItem) {
        return prevCart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevCart, { product, quantity: 1 }];
      }
    });
  };

  const calculateSubtotal = () => {
    return cart.reduce(
      (total, item) => total + item.product.price * item.quantity,
      0
    );
  };

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const shippingCost = cart.reduce(
      (total, item) => total + (item.product.shipping === "G" ? 0 : 50),
      0
    );
    return subtotal + shippingCost;
  };

  return (
    <div className="app-container">
      <Cart
        cart={cart}
        subtotal={calculateSubtotal()}
        total={calculateTotal()}
      />
    </div>
  );
};
