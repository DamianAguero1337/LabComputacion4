import { FaFacebook, FaInstagram, FaTwitter, FaYoutube } from "react-icons/fa";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

function Footer() {
  return (
    <footer className="text-white py-4" style={{ backgroundColor: '#222222' }}>
      <Container>
        <Row className="justify-content-center align-items-center">
          <Col xs="auto" className="social-icon">
            <a href="https://www.instagram.com/hendrixmusica/" target="_blank" rel="noopener noreferrer">
              <FaInstagram />
            </a>
          </Col>
          <Col xs="auto" className="social-icon">
            <a href="https://x.com/MercuryMusic3" target="_blank" rel="noopener noreferrer">
              <FaTwitter />
            </a>
          </Col>
          <Col xs="auto" className="social-icon">
            <a href="https://www.facebook.com/bairesrocks" target="_blank" rel="noopener noreferrer">
              <FaFacebook />
            </a>
          </Col>
          <Col xs="auto" className="social-icon">
            <a href="https://www.youtube.com/channel/UCEqrtYLjy1o4hvaUI0J530w" target="_blank" rel="noopener noreferrer">
              <FaYoutube />
            </a>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}

export default Footer;