import { Navigate, Outlet } from 'react-router-dom';
import { useState } from 'react';
import Usuario, { Roles } from '../types/usuario';

interface Props {
  rol: Roles;
}

function RolUsuario({ rol }: Props) {
  
    const [jsonUsuario, setJSONUsuario] = useState<any>(localStorage.getItem('usuario'));
    const usuarioLogueado:Usuario = JSON.parse(jsonUsuario) as Usuario;
    //si esta logueado y es administrador lo dejo ingresar si no
    if((usuarioLogueado && usuarioLogueado.rol === rol)){
        return <Outlet/>;
    }else if(usuarioLogueado){
        return <Navigate replace to='/#inicio' />;
    }else{
        return <Navigate replace to='/login' />;
    }
    
}
export default RolUsuario;