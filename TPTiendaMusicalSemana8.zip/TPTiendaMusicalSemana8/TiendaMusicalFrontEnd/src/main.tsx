import React, { Suspense } from "react";
import ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Home } from "./components/screens/Home/Home.tsx";
import "bootstrap/dist/css/bootstrap.min.css";
import { Route } from "./routes/Route.tsx";
import { Provider } from "react-redux";
import store from "./redux/Store.ts";
import { ToastContainer } from "react-toastify";
import { DondeEstamos } from "./components/screens/DondeEstamos/DondeEstamos.tsx";
import ABM from "./components/screens/ABM/ABM.tsx";
import Instrumentos from "./components/screens/Productos/Instrumentos.tsx";
import { DetalleInstrumento } from "./components/screens/Productos/DetalleInstrumento.tsx";
import { LoaderPage } from "./components/ui/Loader/LoaderPage.tsx";
import { Login } from "./components/screens/Login/Login.tsx";
const router = createBrowserRouter([
  {
    element: <Route />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "/dondeestamos",
        element: <DondeEstamos />,
      },
      {
        path: "/productos",
        element: <Instrumentos />,
      },
      {
        path: "/productos/:id",
        element: <DetalleInstrumento />,
      },
      {
        path: "/abm",
        element: <ABM />,
      },
      
      { path: "/login", element: <Login /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <Provider store={store}>
      <RouterProvider router={router} />
      <ToastContainer />
    </Provider>
  </React.StrictMode>
);
