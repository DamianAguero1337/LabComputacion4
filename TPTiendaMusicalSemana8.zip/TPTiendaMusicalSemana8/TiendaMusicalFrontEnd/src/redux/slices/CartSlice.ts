import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Instrumento } from '../../types/instrumento';
import { PedidoDetalle } from '../../types/pedido';

interface CartState {
  items: PedidoDetalle[];
}

const initialState: CartState = {
  items: [],
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addItem: (state, action: PayloadAction<Instrumento>) => {
      const  instrumento  = action.payload;
      const existingItemIndex = state.items.findIndex(item => item.instrumento.id === instrumento.id);
      if (existingItemIndex !== -1) {
        state.items[existingItemIndex].cantidad += 1;
      } else {
        state.items.push({ instrumento : instrumento, cantidad: 1 });
      }
    },
    reduceItem: (state, action: PayloadAction<Instrumento>) => {
      const instrumento = action.payload;
      const existingItemIndex = state.items.findIndex(item => item.instrumento.id === instrumento.id);
      if (existingItemIndex !== -1) {
        const item = state.items[existingItemIndex];
        if (item.cantidad > 1) {
          item.cantidad -= 1;
        } else {
          state.items.splice(existingItemIndex, 1);
        }
      }
    },
    removeItem: (state, action: PayloadAction<Instrumento>) => {
      const instrumento = action.payload;
      state.items = state.items.filter(item => item.instrumento.id !== instrumento.id);
    },
    updateItemQuantitySuccess: (state, action: PayloadAction<PedidoDetalle>) => {
      const updatedItem = action.payload;
      const existingItemIndex = state.items.findIndex(item => item.instrumento.id === updatedItem.instrumento.id);
      if (existingItemIndex !== -1) {
        state.items[existingItemIndex] = updatedItem;
      }
    },
    clearItems: (state) => {
      state.items = [];
    },
  },
});

export const { addItem, reduceItem ,removeItem, clearItems } = cartSlice.actions;

export default cartSlice.reducer;
