import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { PedidoDetalle, emptyPedidoDetalle } from "../../types/pedido";

const initialState = { emptyPedidoDetalle };

export const detallePedidoSlice = createSlice({
  name: "Detalle",
  initialState,
  reducers: {},
});

export const fetchPedidoDetalles = createAsyncThunk(
  "pedidoDetalles/fetchPedidoDetalles",
  async () => {
    const response = await fetch("api/pedidos");
    return (await response.json()) as PedidoDetalle[];
  }
);

const pedidoDetalleSlice = createSlice({
  name: "pedidoDetalles",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPedidoDetalles.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPedidoDetalles.fulfilled, (state, action) => {
        state.loading = false;
        state.detalles = action.payload;
      })
      .addCase(fetchPedidoDetalles.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Error al obtener los detalles del pedido";
      });
  },
});

export default pedidoDetalleSlice.reducer;

export const selectPedidoDetalles = (state: RootState) =>
  state.pedidoDetalles.detalles;
