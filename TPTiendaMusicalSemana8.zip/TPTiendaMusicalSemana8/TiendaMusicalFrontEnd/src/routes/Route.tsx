import Footer from "../components/ui/Footer/Footer";
import { NavBar } from "../components/ui/NavBar/NavBar";
import { Outlet } from "react-router-dom";

export const Route = () => {
  return (
    <div>
      <NavBar />
      <Outlet />
      <Footer />
    </div>
  );
};
