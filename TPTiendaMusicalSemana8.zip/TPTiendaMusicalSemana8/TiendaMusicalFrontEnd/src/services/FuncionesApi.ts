import { PreferenceMp } from "../types/pedido";

let url= "http://localhost:8080/"   
export async function createPreferenceMp(idPedido: number) {
    const response = await fetch(url+"instrumentos/productos/create_preference_mp",{
        "method": "POST",
        "body": JSON.stringify(idPedido),
        "headers":{
            "Content-type" : "application/json"
        }
    })
    return await response.json() as PreferenceMp;
}