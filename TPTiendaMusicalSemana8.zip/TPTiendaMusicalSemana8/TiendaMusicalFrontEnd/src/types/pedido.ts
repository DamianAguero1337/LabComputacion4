import { Instrumento } from "./instrumento"

export interface PedidoDetalle{
	id?:number,
	cantidad:number,
	instrumento:Instrumento,
	pedido_id?:number
}
export const emptyPedidoDetalle={
	id:null,
	cantidad:null,
	instrumento_id:null,
	pedido_id:null
}

export interface Pedido{
	id?:number,				
	fechaPedido?: Date,		
	totalPedido?: number,	
	pedidoDetalles?: PedidoDetalle[]	
}
export const emptPedido={
	fechaPedido:null,
	totalPedido:null,
	pedidoDetalles:[]
}
export interface PreferenceMp{
	id?:string,
	statusCode?: number
}