export default class Usuario {
    id?:number;
    usuario: string = "";
    clave: string = "";
    rol:string = "";
}

export enum Roles {
	ADMIN = 'admin',
	USER = 'user',
	VISOR = 'visor'
  }