import mysql from 'mysql';
import fetch from 'node-fetch';

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Damian1234',
  database: 'tp2p1',
  port: 3306 
});

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conexión establecida con la base de datos MySQL');

  for (let code = 1; code <= 300; code++) {
    obtenerJSON(`https://restcountries.com/v2/code/${code}`)
      .then((json) => {
        if (json) {
          const { name, capital = "", region, population, latlng } = json;
          const latitud = latlng.lat;
          const longitud = latlng.lng;
          buscarPais(code, name, capital, region, population, latitud, longitud);
        }
      })
      .catch((error) => {
        console.error('Error al obtener JSON:', error);
      });
  }
});

function obtenerJSON(url) {
  return fetch(url)
    .then((response) => response.json())
    .catch((error) => {
      console.error('Error al realizar la solicitud HTTP:', error);
    });
}

function buscarPais(codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud) {
  const consulta = 'SELECT * FROM Pais WHERE codigoPais = ?';
  connection.query(consulta, [codigoPais], (error, results) => {
    if (error) {
      console.error('Error al buscar país en la base de datos:', error);
      return;
    }
    if (results.length > 0) {
      actualizarPais(codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud);
    } else {
      insertarPais(codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud);
    }
  });
}

function insertarPais(codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud) {
  const consulta = 'INSERT INTO Pais (codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud) VALUES (?, ?, ?, ?, ?, ?, ?)';
  connection.query(consulta, [codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud], (error, results) => {
    if (error) {
      console.error('Error al insertar país en la base de datos:', error);
      return;
    }
    console.log(`País ${nombrePais} insertado correctamente en la base de datos`);
  });
}

function actualizarPais(codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud) {
  const consulta = 'UPDATE Pais SET nombrePais = ?, capitalPais = ?, region = ?, poblacion = ?, latitud = ?, longitud = ? WHERE codigoPais = ?';
  connection.query(consulta, [nombrePais, capitalPais, region, poblacion, latitud, longitud, codigoPais], (error, results) => {
    if (error) {
      console.error('Error al actualizar país en la base de datos:', error);
      return;
    }
    console.log(`País ${nombrePais} actualizado correctamente en la base de datos`);
  });
}