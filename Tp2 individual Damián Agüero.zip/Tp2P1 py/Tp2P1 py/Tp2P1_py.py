import mysql.connector
import requests

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="damian",
    database="tp2p1",
    port=3306
)

if connection.is_connected():
    print("Conexi�n establecida con la base de datos MySQL")
else:
    print("Error al conectar a la base de datos")

def obtener_json(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def buscar_pais(codigo_pais):
    consulta = "SELECT * FROM Pais WHERE codigoPais = %s"
    cursor = connection.cursor()
    cursor.execute(consulta, (codigo_pais,))
    pais = cursor.fetchone()
    cursor.close()
    return pais

def insertar_pais(codigo_pais, nombre_pais, capital_pais, region, poblacion, latitud, longitud):
    consulta = "INSERT INTO Pais (codigoPais, nombrePais, capitalPais, region, poblacion, latitud, longitud) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    cursor = connection.cursor()
    cursor.execute(consulta, (codigo_pais, nombre_pais, capital_pais, region, poblacion, latitud, longitud))
    connection.commit()
    cursor.close()

def actualizar_pais(codigo_pais, nombre_pais, capital_pais, region, poblacion, latitud, longitud):
    consulta = "UPDATE Pais SET nombrePais = %s, capitalPais = %s, region = %s, poblacion = %s, latitud = %s, longitud = %s WHERE codigoPais = %s"
    cursor = connection.cursor()
    cursor.execute(consulta, (nombre_pais, capital_pais, region, poblacion, latitud, longitud, codigo_pais))
    connection.commit()
    cursor.close()

for code in range(1, 301):
    json_data = obtener_json(f"https://restcountries.com/v2/code/{code}")
    if json_data:
        name = json_data.get("name")
        capital = json_data.get("capital", "")
        region = json_data.get("region")
        population = json_data.get("population")
        latlng = json_data.get("latlng")
        if latlng:
            latitud, longitud = latlng

        pais = buscar_pais(code)
        if pais:
            actualizar_pais(code, name, capital, region, population, latitud, longitud)
            print(f"Pa�s {name} actualizado correctamente en la base de datos")
        else:
            insertar_pais(code, name, capital, region, population, latitud, longitud)
            print(f"Pa�s {name} insertado correctamente en la base de datos")

connection.close()
