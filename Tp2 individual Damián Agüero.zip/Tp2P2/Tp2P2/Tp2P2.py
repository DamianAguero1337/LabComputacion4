import requests
from pymongo import MongoClient

# Funci�n para obtener los datos de la API REST
def obtener_datos(code):
    url = f"https://restcountries.com/v2/callingcode/{code}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

# Conexi�n a MongoDB
cliente = MongoClient('localhost', 27017)
db = cliente['paises_db']  
coleccion_paises = db['paises']  

def buscar_pais(codigo_pais):
    return coleccion_paises.find_one({"codigoPais": codigo_pais})

def insertar_pais(codigo_pais, nombre_pais, capital_pais, region, poblacion, latitud, longitud):
    pais = {
        "codigoPais": codigo_pais,
        "nombrePais": nombre_pais,
        "capitalPais": capital_pais,
        "region": region,
        "poblacion": poblacion,
        "latitud": latitud,
        "longitud": longitud
    }
    coleccion_paises.insert_one(pais)

def actualizar_pais(codigo_pais, nombre_pais, capital_pais, region, poblacion, latitud, longitud):
    coleccion_paises.update_one({"codigoPais": codigo_pais}, {"$set": {
        "nombrePais": nombre_pais,
        "capitalPais": capital_pais,
        "region": region,
        "poblacion": poblacion,
        "latitud": latitud,
        "longitud": longitud
    }})

for code in range(1, 301):
    datos = obtener_datos(code)
    if datos:
        name = datos.get("name")
        capital = datos.get("capital", "")
        region = datos.get("region")
        population = datos.get("population")
        latlng = datos.get("latlng")
        if latlng:
            latitud, longitud = latlng

        pais = buscar_pais(code)
        if pais:
            actualizar_pais(code, name, capital, region, population, latitud, longitud)
            print(f"Pa�s {name} actualizado correctamente en la base de datos")
        else:
            insertar_pais(code, name, capital, region, population, latitud, longitud)
            print(f"Pa�s {name} insertado correctamente en la base de datos")
        
def seleccionar_por_region(region):
    documentos = coleccion_paises.find({"region": region})
    for documento in documentos:
        print(documento)

def seleccionar_por_region_y_poblacion(region, poblacion_minima):
    documentos = coleccion_paises.find({"region": region, "poblacion": {"$gt": poblacion_minima}})
    for documento in documentos:
        print(documento)


def seleccionar_por_region_distinta(region):
    documentos = coleccion_paises.find({"region": {"$ne": region}})
    for documento in documentos:
        print(documento)


def actualizar_documento(nombre_actual, nuevo_nombre, nueva_poblacion):
    coleccion_paises.update_one({"name": nombre_actual}, {"$set": {"name": nuevo_nombre, "poblacion": nueva_poblacion}})



def eliminar_documento(codigo_pais):
    coleccion_paises.delete_one({"codigoPais": codigo_pais})



def seleccionar_por_poblacion_rango(poblacion_minima, poblacion_maxima):
    documentos = coleccion_paises.find({"poblacion": {"$gt": poblacion_minima, "$lt": poblacion_maxima}})
    for documento in documentos:
        print(documento)



def seleccionar_ordenados_por_nombre_ascendente():
    documentos = coleccion_paises.find().sort("name", 1)
    for documento in documentos:
        print(documento)



def omitir_primeros_n_documentos(n):
    documentos = coleccion_paises.find().skip(n)
    for documento in documentos:
        print(documento)



def buscar_por_expresion_regular(expresion_regular):
    documentos = coleccion_paises.find({"name": {"$regex": expresion_regular}})
    for documento in documentos:
        print(documento)



def crear_indice():
    coleccion_paises.create_index([("codigoPais", 1)])


#1 Codifique un m�todo que seleccione los documentos de la colecci�n pa�ses donde la regi�n sea Americas. Muestre el resultado por pantalla o consola. 
seleccionar_por_region("Americas")

#2 Codifique un m�todo que seleccione los documentos de la colecci�n pa�ses donde la regi�n sea Americas y la poblaci�n sea mayor a 100000000.  Muestre el resultado por pantalla o consola. 
seleccionar_por_region_y_poblacion("Americas", 100000000)

#3 Codifique un m�todo que seleccione los documentos de la colecci�n pa�ses donde la regi�n sea distinto de Africa. (investigue $ne). Muestre el resultado por pantalla o consola.
seleccionar_por_region_distinta("Africa")

#4 Codifique un m�todo que actualice el documento de la colecci�n pa�ses donde el name sea Egypt, cambiando el name a �Egipto� y la poblaci�n  a 95000000 
actualizar_documento("Egypt", "Egipto", 95000000)

#5 Codifique un m�todo que elimine el documento de la colecci�n pa�ses donde el c�digo del pa�s sea 258 
eliminar_documento(258)

#7 Codifique un m�todo que seleccione los documentos de la colecci�n pa�ses cuya poblaci�n sea mayor a 50000000 y menor a 150000000. Muestre el resultado por pantalla o consola. 
seleccionar_por_poblacion_rango(50000000, 150000000)

#8 Codifique un m�todo que seleccione los documentos de la colecci�n pa�ses ordenados por nombre (name) en forma Ascendente. sort(). Muestre el resultado por pantalla o consola.
seleccionar_ordenados_por_nombre_ascendente()

#11 Cree un nuevo �ndice para la colecci�n pa�ses asignando el campo c�digo  como �ndice.  investigue createIndex()) 
crear_indice()


cliente.close()  # Cerrar la conexi�n a MongoDB

